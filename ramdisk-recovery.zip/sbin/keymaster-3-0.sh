#!/sbin/sh

LD_LIBRARY_PATH=/vendor/lib64:/vendor/lib64/hw:/sbin; /sbin/android.hardware.keymaster@3.0-service
